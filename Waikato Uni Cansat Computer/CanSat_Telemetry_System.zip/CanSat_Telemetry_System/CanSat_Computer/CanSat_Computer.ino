#include <Wire.h>
#include <MPU6050_light.h>
#include <BMP180I2C.h>
#include <TinyGPS++.h>
#include <SoftwareSerial.h>
#include <SPI.h>
#include <RF24.h>
#include <STM32SD.h>

// ============================================================
//  CANSAT COMPUTER — CanSat Flight Computer (STM32F405RGT6)
//  Board part number: Generic F405RGTx
//  USB serial = Serial   |  GY-87 on I2C1 (PB6=SCL, PB7=SDA)
//  GPS L80 via SoftwareSerial (PA1=RX, PA0=TX)
//  NRF24 on SPI1: SCK=PA5, MISO=PA6, MOSI=PA7, CE=PB4, CSN=PB3
//  SERVO on PB8 (HardwareTimer, TIM4_CH3)
//  BATTERY ADC on PB0 (raw analogRead value)
//  SD CARD on SDIO (STM32SD library), card-detect DET = PC2
//  LED PC13 (active-low)
//
//  Telemetry (8 floats = 32 bytes):
//    accY, voltage, baroAlt, lat, lng, gpsAlt, sats, hdop
//  SD write status is encoded in the SIGN of 'voltage':
//    voltage >= 0  -> SD write OK (or no card check)
//    voltage <  0  -> SD write FAILED (abs value still the ADC reading)
//
//  Return link: ground station sends a servo angle (0-180) as an
//  NRF24 ACK PAYLOAD, applied to the servo on PB8.
// ============================================================

// ---- I2C addresses ----
#define BMP180_I2C_ADDR 0x77
#define MPU6050_ADDR    0x68
#define HMC5883L_ADDR   0x1E
#define QMC5883L_ADDR   0x0D

#define LED_PIN   PC13
#define SERVO_PIN PB8
#define ADC_PIN   PB0      // battery voltage divider (raw ADC value sent)

// Servo driven directly by HardwareTimer (Servo library mis-scales on this
// core). TIM4 clock on the F405 is 84 MHz; prescaler 84 => 1 tick = 1 us.
#define SERVO_PRESCALER 84
#define SERVO_FRAME_US  20000     // 20 ms => 50 Hz
#define SERVO_MIN_US 1000
#define SERVO_MAX_US 2000

// ---- NRF24 ----
#define NRF_CE  PB4
#define NRF_CSN PB3
RF24 radio(NRF_CE, NRF_CSN);
const byte address[6] = "CSAT1";

// ---- SD ----
#define SD_DETECT_PIN PC2
char logFilename[16] = "";     // set at boot to logNNN.csv
bool sdReady = false;
File logFile;
unsigned long lastFlush = 0;
unsigned long sdRowsSinceFlush = 0;
unsigned long sdWriteFails = 0;

MPU6050 mpu(Wire);
BMP180I2C bmp(BMP180_I2C_ADDR);
TinyGPSPlus gps;
SoftwareSerial gpsSerial(PA1, PA0);   // (RX, TX)

// Servo via HardwareTimer
HardwareTimer *servoTimer;
uint32_t servoChannel;

byte magType = 0;
unsigned long lastSend = 0;
unsigned long lastBlink = 0;
unsigned long sendCount = 0;
unsigned long successCount = 0;

byte servoAngle = 90;

// Sea-level pressure for barometric altitude (Pa). Raw altitude is logged;
// the ground station applies any "zero" offset on its side.
const float SEA_LEVEL_PA = 101325.0;

// Telemetry packet (8 floats = 32 bytes)
struct __attribute__((packed)) Telemetry {
  float accY;       // g (vertical-ish axis kept)
  float voltage;    // raw ADC value; negative sign = SD write failed
  float baroAlt;    // barometric altitude (m)
  float lat;
  float lng;
  float gpsAlt;     // GPS altitude (m)
  float satellites; // number of satellites in use
  float hdop;       // horizontal dilution of precision
};
Telemetry tlm;

// Maintenance text packet: same 32 bytes, but carries a short text line
// (file listing entries or file contents) instead of sensor data.
// tag: 'L'=listing line, 'D'=file data line, 'E'=end of transfer, 'C'=cleared
struct __attribute__((packed)) TextPacket {
  char tag;
  char text[31];
};
TextPacket txt;

// Ack payload from ground: servo angle + command code
// cmdCode: 0=none, 1=list files, 2=get file, 3=delete file,
//          5=start logging, 6=stop logging, 7=ping (one reading)
struct __attribute__((packed)) Command {
  uint8_t servoAngle;
  uint8_t zeroAlt;     // 1 = capture current altitude as the new zero
  uint8_t cmdCode;     // command
  uint8_t arg;         // file index for get/delete
};
Command cmd;

// ---- Operating state ----
// IDLE: heartbeat only (a tiny alive packet), no sensor stream, no SD.
// LOGGING: stream telemetry + write SD.
// Maintenance commands (list/get/delete/ping) are handled on demand and
// return to whatever state we were in.
bool loggingActive = false;  // set by start/stop logging commands
File xferFile;
byte pendingCmd = 0;         // command received, to act on next loop
byte pendingArg = 0;
byte lastCmdCode = 0;        // de-dupe: ignore repeats of the same command

// Altitude offsets applied on the CanSat when a zero command is received.
float baroAltOffset = 0.0f;
float gpsAltOffset  = 0.0f;
bool  zeroPending   = false;

bool i2cPresent(byte addr) {
  Wire.beginTransmission(addr);
  return (Wire.endTransmission() == 0);
}

void enableMpuBypass() {
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x37); Wire.write(0x02);
  Wire.endTransmission();
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x6B); Wire.write(0x00);
  Wire.endTransmission();
}

void setupMagnetometer() {
  if (i2cPresent(HMC5883L_ADDR)) {
    magType = 1;
    Wire.beginTransmission(HMC5883L_ADDR); Wire.write(0x00); Wire.write(0x70); Wire.endTransmission();
    Wire.beginTransmission(HMC5883L_ADDR); Wire.write(0x01); Wire.write(0x20); Wire.endTransmission();
    Wire.beginTransmission(HMC5883L_ADDR); Wire.write(0x02); Wire.write(0x00); Wire.endTransmission();
    Serial.println("Magnetometer: HMC5883L");
  } else if (i2cPresent(QMC5883L_ADDR)) {
    magType = 2;
    Wire.beginTransmission(QMC5883L_ADDR); Wire.write(0x0B); Wire.write(0x01); Wire.endTransmission();
    Wire.beginTransmission(QMC5883L_ADDR); Wire.write(0x09); Wire.write(0x1D); Wire.endTransmission();
    Serial.println("Magnetometer: QMC5883L");
  } else {
    magType = 0;
    Serial.println("Magnetometer: NOT FOUND");
  }
}

float baroAltitude(float pressurePa) {
  if (isnan(pressurePa) || pressurePa <= 0) return NAN;
  return 44330.0 * (1.0 - pow(pressurePa / SEA_LEVEL_PA, 0.1903));
}

void servoWriteMicros(uint32_t us) {
  servoTimer->setCaptureCompare(servoChannel, us, TICK_COMPARE_FORMAT);
}
void servoWriteAngle(byte angle) {
  if (angle > 180) angle = 180;
  uint32_t us = map(angle, 0, 180, SERVO_MIN_US, SERVO_MAX_US);
  servoWriteMicros(us);
}

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);
  pinMode(ADC_PIN, INPUT_ANALOG);

  Serial.begin(9600);
  delay(2000);
  Serial.println();
  Serial.println("===== CANSAT COMPUTER =====");

  // ---- Servo (HardwareTimer on PB8) ----
  {
    PinName pn = digitalPinToPinName(SERVO_PIN);
    TIM_TypeDef *Instance = (TIM_TypeDef *)pinmap_peripheral(pn, PinMap_PWM);
    servoChannel = STM_PIN_CHANNEL(pinmap_function(pn, PinMap_PWM));
    servoTimer = new HardwareTimer(Instance);
    servoTimer->setMode(servoChannel, TIMER_OUTPUT_COMPARE_PWM1, SERVO_PIN);
    servoTimer->setPrescaleFactor(SERVO_PRESCALER);
    servoTimer->setOverflow(SERVO_FRAME_US, TICK_FORMAT);
    servoWriteAngle(servoAngle);
    servoTimer->resume();
  }

  Wire.begin();

  // ---- MPU6050 ----
  byte status = mpu.begin();
  Serial.print("MPU6050: ");
  Serial.println(status == 0 ? "OK" : "FAILED");
  if (status == 0) mpu.calcOffsets();

  enableMpuBypass();
  delay(10);

  // ---- BMP180 ----
  Serial.print("BMP180: ");
  if (bmp.begin()) {
    bmp.resetToDefaults();
    bmp.setSamplingMode(BMP180MI::MODE_UHR);
    Serial.println("OK");
  } else {
    Serial.println("FAILED");
  }

  // ---- Magnetometer ----
  setupMagnetometer();

  // ---- GPS ----
  gpsSerial.begin(9600);
  Serial.println("GPS started");

  // ---- SD card (SDIO) ----
  // Only verify the card is present at boot. The actual log file is created
  // fresh when logging STARTS (so each logging session gets its own file).
  Serial.print("SD: ");
  if (SD.begin(SD_DETECT_PIN)) {
    sdReady = true;
    Serial.println("card OK (ready to log on command)");
  } else {
    sdReady = false;
    Serial.println("NO CARD");
  }

  // ---- NRF24 ----
  Serial.print("NRF24: ");
  if (radio.begin()) {
    radio.setPALevel(RF24_PA_HIGH);
    radio.setDataRate(RF24_250KBPS);
    radio.setChannel(108);
    radio.enableAckPayload();
    radio.enableDynamicPayloads();
    radio.openWritingPipe(address);
    radio.stopListening();
    Serial.println("OK");
  } else {
    Serial.println("FAILED (check wiring / power)");
  }

  Serial.println("Init complete");
}

// Create a fresh numbered log file (logNNN.csv) with a header. Called when
// logging starts, so each session is its own file.
bool openNewLog() {
  if (!sdReady) { if (!SD.begin(SD_DETECT_PIN)) return false; sdReady = true; }
  for (int n = 1; n < 1000; n++) {
    snprintf(logFilename, sizeof(logFilename), "log%03d.csv", n);
    if (!SD.exists(logFilename)) break;
  }
  logFile = SD.open(logFilename, FILE_WRITE);
  if (!logFile) return false;
  logFile.println("t_ms,accY,adc,baroAlt,lat,lng,gpsAlt,sats,hdop");
  logFile.flush();
  Serial.print("Logging to "); Serial.println(logFilename);
  return true;
}

// Writes one row to the open log file. Verifies the write landed, flushes
// periodically (every ~2 s) rather than every row, and reopens the file if a
// write fails — which is what was silently stopping logging before.
bool logToSD(unsigned long t, float ay, int adc, float baroAlt,
             float lat, float lng, float gpsAlt, float sats, float hdop) {
  if (!sdReady) return false;

  // If the handle went bad, try to reopen before writing, seeking to the end
  // so we append rather than overwrite from the start.
  if (!logFile) {
    logFile = SD.open(logFilename, FILE_WRITE);
    if (!logFile) {
      sdWriteFails++;
      // If reopening keeps failing, the card may have dropped off the bus.
      // Re-initialise the whole SD interface to recover it.
      if (sdWriteFails % 10 == 0) {
        SD.begin(SD_DETECT_PIN);
      }
      return false;
    }
    logFile.seek(logFile.size());
  }

  // Build the row and write it; println returns the number of bytes written.
  size_t n = 0;
  n += logFile.print(t);        logFile.print(',');
  n += logFile.print(ay, 3);    logFile.print(',');
  n += logFile.print(adc);      logFile.print(',');
  n += logFile.print(baroAlt,2);logFile.print(',');
  n += logFile.print(lat, 6);   logFile.print(',');
  n += logFile.print(lng, 6);   logFile.print(',');
  n += logFile.print(gpsAlt,2); logFile.print(',');
  n += logFile.print((int)sats);logFile.print(',');
  n += logFile.println(hdop,2);

  if (n == 0) {
    // Write produced nothing — handle likely stale. Close so we reopen next time.
    sdWriteFails++;
    logFile.close();
    return false;
  }

  // Flush periodically (every ~2 s or 8 rows) rather than every row — gentle
  // on the card, and never risks more than a couple of seconds on power loss.
  sdRowsSinceFlush++;
  if (millis() - lastFlush >= 2000 || sdRowsSinceFlush >= 8) {
    logFile.flush();
    lastFlush = millis();
    sdRowsSinceFlush = 0;
  }
  return true;
}

// ---- Maintenance helpers (file transfer over the radio) ----

// Send one 32-byte text packet with the given tag and text; waits for ack.
bool sendTextPacket(char tag, const char* s) {
  memset(&txt, 0, sizeof(txt));
  txt.tag = tag;
  strncpy(txt.text, s, sizeof(txt.text) - 1);
  return radio.write(&txt, sizeof(txt));
}

// Recursively list files in the card root, sending one 'L' packet per file
// as "name,size". Then send an 'E' end marker.
void doListing() {
  File root = SD.open("/");
  if (root) {
    while (true) {
      File entry = root.openNextFile();
      if (!entry) break;
      if (!entry.isDirectory()) {
        char line[31];
        snprintf(line, sizeof(line), "%s,%lu", entry.name(), (unsigned long)entry.size());
        sendTextPacket('L', line);
        delay(20);
      }
      entry.close();
    }
    root.close();
  }
  sendTextPacket('E', "");   // end of listing
}

// Open the Nth file (by directory order) and stream it line by line as 'D'
// packets, then an 'E' end marker. Long lines are split to fit 30 chars.
void doGetFile(byte index) {
  File root = SD.open("/");
  if (!root) { sendTextPacket('E', "no root"); return; }
  byte i = 0;
  File target;
  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    if (!entry.isDirectory()) {
      if (i == index) { target = entry; break; }
      i++;
    }
    entry.close();
  }
  if (!target) { root.close(); sendTextPacket('E', "not found"); return; }

  // Send a header line with the filename so the GUI can name the download.
  char hdr[31];
  snprintf(hdr, sizeof(hdr), "%s", target.name());
  sendTextPacket('N', hdr);   // 'N' = filename (not file data)
  delay(20);

  // Read the file and send it preserving line boundaries. A logical CSV line
  // may be longer than 30 chars, so we split it across packets:
  //   'D' = a chunk that is NOT the end of the line (more follows)
  //   'd' = the final chunk of the line (line ends here)
  // The GUI concatenates 'D' chunks and completes the line on 'd'.
  char buf[31];
  byte pos = 0;
  while (target.available()) {
    char c = target.read();
    if (c == '\n') {
      buf[pos] = 0;
      sendTextPacket('d', buf);   // end of this line
      delay(12);
      pos = 0;
    } else if (c == '\r') {
      // skip
    } else {
      buf[pos++] = c;
      if (pos >= 30) {            // chunk full but line continues
        buf[pos] = 0;
        sendTextPacket('D', buf); // continuation, no line break
        delay(12);
        pos = 0;
      }
    }
  }
  if (pos > 0) { buf[pos] = 0; sendTextPacket('d', buf); delay(12); }
  target.close();
  root.close();
  sendTextPacket('E', "");   // end of file
}

// Delete every file in the card root (the logs). Keeps the card usable.
// Delete a single file chosen by its index in the directory listing.
void doDeleteFile(byte index) {
  // If we're about to delete the file we're actively logging to, close it.
  File root = SD.open("/");
  if (!root) { sendTextPacket('E', "no root"); return; }
  byte i = 0;
  char nameToDelete[32] = "";
  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    if (!entry.isDirectory()) {
      if (i == index) {
        strncpy(nameToDelete, entry.name(), sizeof(nameToDelete) - 1);
        nameToDelete[sizeof(nameToDelete)-1] = 0;
        entry.close();
        break;
      }
      i++;
    }
    entry.close();
  }
  root.close();

  if (nameToDelete[0] == 0) { sendTextPacket('E', "not found"); return; }

  // If it's the current log file, close it first.
  if (logFile && strcmp(nameToDelete, logFilename) == 0) {
    logFile.close();
  }
  if (SD.remove(nameToDelete)) {
    char msg[31];
    snprintf(msg, sizeof(msg), "deleted %s", nameToDelete);
    sendTextPacket('X', msg);
  } else {
    sendTextPacket('E', "delete failed");
  }
}

// Send one fresh set of sensor readings as a single CSV 'P' (ping) packet.
void doPing() {
  mpu.update();
  float ay = mpu.getAccY();
  int adc = analogRead(ADC_PIN);
  float baroAlt = NAN;
  if (bmp.measureTemperature()) { unsigned long t0=millis(); while(!bmp.hasValue()){ if(millis()-t0>50) break; } (void)bmp.getTemperature(); }
  if (bmp.measurePressure())    { unsigned long t0=millis(); while(!bmp.hasValue()){ if(millis()-t0>50) break; } if(bmp.hasValue()) baroAlt=baroAltitude(bmp.getPressure()); }
  float lat=0,lng=0,gpsAlt=0,sats=0,hdop=0;
  if (gps.location.isValid()) { lat=gps.location.lat(); lng=gps.location.lng(); }
  if (gps.altitude.isValid())  gpsAlt=gps.altitude.meters();
  if (gps.satellites.isValid())sats=gps.satellites.value();
  if (gps.hdop.isValid())      hdop=gps.hdop.hdop();
  bool gpsAlive = (gps.charsProcessed() > 10);

  // Pack into a text line the ground station forwards as a "PING" CSV.
  char line[31];
  // Keep it compact; the GUI parses these fields.
  snprintf(line, sizeof(line), "%.2f,%d,%.1f", ay, adc, isnan(baroAlt)?0.0:baroAlt);
  sendTextPacket('P', line);
  // Second line with GPS since it won't all fit in 30 chars.
  char line2[31];
  snprintf(line2, sizeof(line2), "%.5f,%.5f", lat, lng);
  sendTextPacket('Q', line2);
  char line3[31];
  snprintf(line3, sizeof(line3), "%.1f,%d,%.1f,%d", gpsAlt, (int)sats, hdop, gpsAlive?1:0);
  sendTextPacket('R', line3);
  sendTextPacket('E', "");
}

void loop() {
  // ---- 1 Hz heartbeat: steady blink = operating normally ----
  // Toggle every 500 ms => on for 500 ms, off for 500 ms = 1 Hz.
  if (millis() - lastBlink >= 500) {
    lastBlink = millis();
    digitalWrite(LED_PIN, !digitalRead(LED_PIN));
  }

  // ---- Handle a pending SD/maintenance command ----
  // These take over the radio briefly to stream text back to the ground.
  if (pendingCmd != 0) {
    byte c = pendingCmd;
    byte a = pendingArg;
    pendingCmd = 0;
    radio.stopListening();          // ensure we're transmitting
    if      (c == 1) doListing();
    else if (c == 2) doGetFile(a);
    else if (c == 3) doDeleteFile(a);
    else if (c == 5) { loggingActive = openNewLog(); Serial.println(loggingActive ? "LOGGING START" : "LOG OPEN FAILED"); }
    else if (c == 6) { loggingActive = false; if (logFile) logFile.close(); Serial.println("LOGGING STOP"); }
    else if (c == 7) doPing();
    else if (c == 8) {
      zeroPending = true;           // capture offset on next reading
      lastCmdCode = 0;              // allow Zero to be pressed again later
      Serial.println("ZERO requested");
    }
    return;
  }

  while (gpsSerial.available()) {
    gps.encode(gpsSerial.read());
  }

  mpu.update();

  if (millis() - lastSend >= 500) {   // 2 Hz
    lastSend = millis();

    // ---- IDLE: not logging -> send a lightweight heartbeat packet only ----
    // The GUI uses this to show "connected / alive" without any data stream.
    if (!loggingActive) {
      radio.stopListening();
      sendTextPacket('H', "alive");   // heartbeat
      // CRITICAL: read the ack payload here so commands (start logging, ping,
      // list, etc.) are received while idle. Check regardless of write result.
      if (radio.isAckPayloadAvailable()) {
        radio.read(&cmd, sizeof(cmd));
        if (cmd.servoAngle <= 180) { servoAngle = cmd.servoAngle; servoWriteAngle(servoAngle); }
        if (cmd.zeroAlt) zeroPending = true;
        if (cmd.cmdCode != 0 && cmd.cmdCode != lastCmdCode) {
          pendingCmd = cmd.cmdCode; pendingArg = cmd.arg;
          lastCmdCode = cmd.cmdCode;
        }
        if (cmd.cmdCode == 0) lastCmdCode = 0;   // reset when ground clears it
      }
      return;
    }

    // ================= LOGGING ACTIVE from here =================

    // ---- Read sensors ----
    float ay = mpu.getAccY();        // vertical acceleration

    int adc = analogRead(ADC_PIN);   // raw battery ADC value

    float baroAlt = NAN;
    // Non-blocking BMP180 read with a timeout so a stuck sensor can't hang
    // the loop. Temperature MUST be measured before pressure: the BMP180
    // uses the temperature reading to compensate the pressure result.
    if (bmp.measureTemperature()) {
      unsigned long t0 = millis();
      while (!bmp.hasValue()) {
        if (millis() - t0 > 50) break;   // 50 ms timeout
      }
      (void)bmp.getTemperature();        // consume the value
    }
    if (bmp.measurePressure()) {
      unsigned long t0 = millis();
      while (!bmp.hasValue()) {
        if (millis() - t0 > 50) break;
      }
      if (bmp.hasValue()) baroAlt = baroAltitude(bmp.getPressure());
    }

    float lat = 0, lng = 0, gpsAlt = 0;
    float sats = 0, hdop = 0;
    if (gps.location.isValid()) {
      lat = gps.location.lat();
      lng = gps.location.lng();
    }
    if (gps.altitude.isValid())    gpsAlt = gps.altitude.meters();
    if (gps.satellites.isValid())  sats   = gps.satellites.value();
    if (gps.hdop.isValid())        hdop   = gps.hdop.hdop();

    // GPS "sign of life": has the module sent us any characters at all?
    // If chars are flowing, the GPS is communicating even without a fix.
    bool gpsAlive = (gps.charsProcessed() > 10);

    // ---- Altitude zeroing (commanded from the ground) ----
    // When a zero is pending, capture the current RAW readings as offsets.
    if (zeroPending) {
      if (!isnan(baroAlt)) baroAltOffset = baroAlt;
      gpsAltOffset = gpsAlt;           // 0 if no GPS fix yet
      zeroPending = false;
      Serial.print("ALT ZEROED  baroOffset="); Serial.print(baroAltOffset,2);
      Serial.print("  gpsOffset="); Serial.println(gpsAltOffset,2);
    }
    // Apply offsets so both the logged and transmitted altitudes are relative.
    float baroAltZ = isnan(baroAlt) ? NAN : (baroAlt - baroAltOffset);
    float gpsAltZ  = gpsAlt - gpsAltOffset;

    // ---- Log to SD, get success flag ----
    unsigned long t = millis();
    bool sdOk = logToSD(t, ay, adc, baroAltZ, lat, lng, gpsAltZ, sats, hdop);

    // ---- Fill telemetry (encode SD status in sign of voltage) ----
    tlm.accY = ay;
    tlm.voltage = sdOk ? (float)adc : -(float)adc;   // negative = SD failed
    tlm.baroAlt = baroAltZ;    // altitude relative to the commanded zero
    tlm.lat = lat;
    tlm.lng = lng;
    tlm.gpsAlt = gpsAltZ;      // altitude relative to the commanded zero
    tlm.satellites = sats;
    // Encode GPS-alive in the SIGN of hdop: negative = GPS is communicating
    // (chars flowing) even if it has no position fix yet. HDOP is always >=0.
    tlm.hdop = gpsAlive ? -(hdop + 0.001f) : (hdop);

    // ---- Transmit + read servo command from ack ----
    bool ok = radio.write(&tlm, sizeof(tlm));
    sendCount++;
    if (ok) {
      successCount++;
      if (radio.isAckPayloadAvailable()) {
        radio.read(&cmd, sizeof(cmd));
        byte a = cmd.servoAngle;
        if (a <= 180 && a != servoAngle) {
          servoAngle = a;
          servoWriteAngle(servoAngle);
        }
        // Zero-altitude command: flag it so the NEXT reading captures offsets.
        if (cmd.zeroAlt) zeroPending = true;
        // SD/maintenance command: latch it to act on next loop iteration.
        if (cmd.cmdCode != 0 && cmd.cmdCode != lastCmdCode) {
          pendingCmd = cmd.cmdCode;
          pendingArg = cmd.arg;
          lastCmdCode = cmd.cmdCode;
        }
        if (cmd.cmdCode == 0) lastCmdCode = 0;
      }
    }

    // ---- Debug ----
    Serial.print(ok ? "[TX OK]   #" : "[TX FAIL] #");
    Serial.print(sendCount);
    Serial.print("  SD:");   Serial.print(sdOk ? "OK" : "FAIL");
    Serial.print("(fails:"); Serial.print(sdWriteFails); Serial.print(")");
    Serial.print("  Servo:");Serial.print(servoAngle);
    Serial.print("  accY:"); Serial.print(ay,2);
    Serial.print("  ADC:");  Serial.print(adc);
    Serial.print("  baroAlt:"); Serial.print(baroAlt,1);
    Serial.print("  GPS:");  Serial.print(lat,5); Serial.print(","); Serial.print(lng,5); Serial.print("@"); Serial.print(gpsAlt,0);
    Serial.print("  sats:"); Serial.print((int)sats);
    Serial.print("  hdop:"); Serial.print(hdop,1);
    Serial.print("  GPSalive:"); Serial.print(gpsAlive ? "Y" : "N");
    Serial.println();
  }
}
