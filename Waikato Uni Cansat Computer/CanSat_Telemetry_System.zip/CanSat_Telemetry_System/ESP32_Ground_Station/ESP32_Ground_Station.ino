#include <SPI.h>
#include <RF24.h>

// ============================================================
//  ESP32 GROUND STATION  (NRF24L01) — command-driven + maintenance
//  For use with the web serial dashboard (GUI.html).
//
//  NRF24 wiring to ESP32 (VSPI):
//    GND->GND  VCC->3.3V(never 5V)  CE->GPIO4  CSN->GPIO5
//    SCK->GPIO18  MOSI->GPIO23  MISO->GPIO19  IRQ->n/c
//  Add a 10uF cap across the NRF24 VCC/GND at the module.
//  Serial / dashboard baud: 115200.
//
//  Commands IN from the GUI (one per line):
//    S:<angle>   servo 0..180
//    Z           zero altitude
//    LOG:START   start logging (CanSat streams + writes SD)
//    LOG:STOP    stop logging
//    PING        request one fresh sensor reading
//    LIST        list SD files
//    GET:<n>     download file index n
//    DEL:<n>     delete file index n
//
//  Lines OUT to the GUI:
//    Telemetry CSV (while logging):
//      T,accY,adc,sdOK,baroAlt,lat,lng,gpsAlt,sats,hdop,gpsAlive
//    #alive               heartbeat (CanSat connected, idle)
//    #FILE <name>,<size>  a file listing entry
//    #DATA <text>         a line of file contents during download
//    #ENDLIST / #ENDFILE  end markers
//    #DELETED <name>      file deleted
//    #PING <csv>          single ping reading
//    #... other status/comments
// ============================================================

#define NRF_CE  4
#define NRF_CSN 5
RF24 radio(NRF_CE, NRF_CSN);
const byte address[6] = "CSAT1";

// Telemetry packet (must match CanSat)
struct __attribute__((packed)) Telemetry {
  float accY;
  float voltage;   // raw ADC; negative sign => SD write failed
  float baroAlt;
  float lat;
  float lng;
  float gpsAlt;
  float satellites;
  float hdop;
};

// Maintenance text packet (same 32 bytes)
struct __attribute__((packed)) TextPacket {
  char tag;
  char text[31];
};

// Command to CanSat (ack payload)
struct __attribute__((packed)) Command {
  uint8_t servoAngle;
  uint8_t zeroAlt;
  uint8_t cmdCode;   // 0 none,1 list,2 get,3 delete,5 startlog,6 stoplog,7 ping
  uint8_t arg;
};
Command cmd = { 90, 0, 0, 0 };

// A pending command is re-loaded into the ack payload on the next several
// packets so it isn't lost if one ack payload is dropped.
uint8_t pendingCode = 0, pendingArgV = 0;
int pendingRepeat = 0;

unsigned long lastPacket = 0;

// Buffers for reassembling a ping (arrives as 3 packets P,Q,R)
String pingP = "", pingQ = "", pingR = "";

void armCommand(uint8_t code, uint8_t arg=0) {
  pendingCode = code;
  pendingArgV = arg;
  pendingRepeat = 6;      // re-arm on the next 6 received packets
  cmd.cmdCode = code;
  cmd.arg = arg;
  radio.writeAckPayload(0, &cmd, sizeof(cmd));
}

String inLine = "";
void handleSerialInput() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (inLine.startsWith("S:")) {
        int a = inLine.substring(2).toInt();
        if (a < 0) a = 0; if (a > 180) a = 180;
        cmd.servoAngle = (uint8_t)a;
        radio.writeAckPayload(0, &cmd, sizeof(cmd));
        Serial.print("#servo set to "); Serial.println(a);
      }
      else if (inLine.startsWith("Z")) {
        armCommand(8, 0);   // zero altitude, reliably repeated
        Serial.println("#zero altitude sent");
      }
      else if (inLine.startsWith("LOG:START")) { armCommand(5); Serial.println("#logging start sent"); }
      else if (inLine.startsWith("LOG:STOP"))  { armCommand(6); Serial.println("#logging stop sent"); }
      else if (inLine.startsWith("PING"))      { armCommand(7); Serial.println("#ping sent"); }
      else if (inLine.startsWith("LIST"))      { armCommand(1); Serial.println("#list requested"); }
      else if (inLine.startsWith("GET:"))      { armCommand(2, (uint8_t)inLine.substring(4).toInt()); Serial.println("#get requested"); }
      else if (inLine.startsWith("DEL:"))      { armCommand(3, (uint8_t)inLine.substring(4).toInt()); Serial.println("#delete requested"); }
      inLine = "";
    } else {
      inLine += c;
      if (inLine.length() > 24) inLine = "";
    }
  }
}

// Decide whether a 32-byte payload is a TextPacket (first byte is a known tag)
// or Telemetry. Tags are ASCII letters we chose; a float's first byte almost
// never coincides, and telemetry is only sent while logging anyway.
bool isTextTag(char t) {
  return (t=='H'||t=='L'||t=='D'||t=='d'||t=='N'||t=='E'||t=='X'||t=='P'||t=='Q'||t=='R'||t=='C');
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("#CanSat telemetry CSV: T,accY,adc,sdOK,baroAlt,lat,lng,gpsAlt,sats,hdop,gpsAlive");

  if (radio.begin()) {
    radio.setPALevel(RF24_PA_HIGH);
    radio.setDataRate(RF24_250KBPS);
    radio.setChannel(108);
    radio.enableAckPayload();
    radio.enableDynamicPayloads();
    radio.openReadingPipe(0, address);
    radio.writeAckPayload(0, &cmd, sizeof(cmd));
    radio.startListening();
    Serial.println("#NRF24 OK - waiting for CanSat");
  } else {
    Serial.println("#NRF24 FAILED - check wiring / 3.3V / decoupling cap");
  }
}

void loop() {
  handleSerialInput();

  if (radio.available()) {
    // Peek the payload into a buffer, then interpret by first byte.
    uint8_t buf[32];
    radio.read(buf, sizeof(buf));
    lastPacket = millis();

    // Re-arm the pending command so it survives dropped ack payloads.
    if (pendingRepeat > 0) {
      cmd.cmdCode = pendingCode; cmd.arg = pendingArgV;
      pendingRepeat--;
    } else {
      cmd.cmdCode = 0; cmd.arg = 0;
    }
    radio.writeAckPayload(0, &cmd, sizeof(cmd));

    char tag = (char)buf[0];
    if (isTextTag(tag)) {
      TextPacket* tp = (TextPacket*)buf;
      char t = tp->tag;
      // Ensure null-termination for safety
      char text[31]; memcpy(text, tp->text, 30); text[30] = 0;

      if (t == 'H') {
        Serial.println("#alive");
      } else if (t == 'L') {
        Serial.print("#FILE "); Serial.println(text);
      } else if (t == 'N') {
        Serial.print("#FNAME "); Serial.println(text);
      } else if (t == 'D') {
        Serial.print("#DCONT "); Serial.println(text);
      } else if (t == 'd') {
        Serial.print("#DATA "); Serial.println(text);
      } else if (t == 'X') {
        Serial.print("#DELETED "); Serial.println(text);
      } else if (t == 'E') {
        Serial.println("#END");
      } else if (t == 'P') { pingP = text; }
        else if (t == 'Q') { pingQ = text; }
        else if (t == 'R') {
          pingR = text;
          // Emit the reassembled ping as one line: accY,adc,baro,lat,lng,gpsAlt,sats,hdop,alive
          Serial.print("#PING ");
          Serial.print(pingP); Serial.print(',');
          Serial.print(pingQ); Serial.print(',');
          Serial.println(pingR);
          pingP = pingQ = pingR = "";
        }
    } else {
      // Telemetry packet (only sent while logging)
      Telemetry* tlm = (Telemetry*)buf;
      bool sdOK = (tlm->voltage >= 0);
      long adc = (long)fabs(tlm->voltage);
      bool gpsAlive = (tlm->hdop < 0);
      float hdopAbs = fabs(tlm->hdop);

      Serial.print(millis());      Serial.print(',');
      Serial.print(tlm->accY, 3);  Serial.print(',');
      Serial.print(adc);           Serial.print(',');
      Serial.print(sdOK ? 1 : 0);  Serial.print(',');
      Serial.print(tlm->baroAlt,2);Serial.print(',');
      Serial.print(tlm->lat, 6);   Serial.print(',');
      Serial.print(tlm->lng, 6);   Serial.print(',');
      Serial.print(tlm->gpsAlt,2); Serial.print(',');
      Serial.print((int)tlm->satellites); Serial.print(',');
      Serial.print(hdopAbs,2);     Serial.print(',');
      Serial.println(gpsAlive ? 1 : 0);
    }
  }

  if (millis() - lastPacket > 4000 && lastPacket != 0) {
    Serial.println("#link lost");
    lastPacket = millis();
  }
}
