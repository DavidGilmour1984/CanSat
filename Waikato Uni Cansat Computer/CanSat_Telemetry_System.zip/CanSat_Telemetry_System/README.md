# CanSat Telemetry & Control System

A complete two-way wireless telemetry and control system for a CanSat / model
rocket flight computer, with a browser-based ground station GUI.

## What's in this package

```
CanSat_Computer/            Firmware for the CanSat flight computer (STM32F405)
ESP32_Ground_Station/       Ground station firmware for an ESP32
Arduino_Nano_Ground_Station/ Ground station firmware for an Arduino Nano
GUI/                        GUI.html — the browser dashboard (Chrome/Edge)
Documentation/              Detailed docs + Arduino IDE programming guide
```

Use **one** ground station (ESP32 or Nano) — they behave identically and both
work with the GUI. The `.ino` files are inside folders of the same name so they
open straight in the Arduino IDE.

## Hardware quick reference

**CanSat (STM32F405RGT6)**
- Sensors (GY-87) on I2C1: SCL=PB6, SDA=PB7 (MPU6050, BMP180, HMC/QMC mag)
- GPS L80 (SoftwareSerial): PA1=RX, PA0=TX
- NRF24 on SPI1: SCK=PA5, MISO=PA6, MOSI=PA7, CE=PB4, CSN=PB3
- Servo (HardwareTimer): PB8
- Battery ADC: PB0
- SD card: SDIO, card-detect PC2
- LED: PC13 (1 Hz heartbeat = running normally)

**ESP32 ground station** — NRF24 on VSPI: CE=GPIO4, CSN=GPIO5, SCK=18, MOSI=23, MISO=19
**Nano ground station** — NRF24: CE=D7, CSN=D8, SCK=D13, MOSI=D11, MISO=D12

**Always** fit a 10µF cap across each NRF24 VCC/GND, and give the SD card and
servo solid power separate from the radio.

## Arduino libraries required

- RF24 (TMRh20)
- MPU6050_light (rfetick)
- BMP180MI (Gregor Christandl) — include `<BMP180I2C.h>`
- TinyGPSPlus (Mikal Hart)
- STM32SD (ships with the STM32 core) — CanSat only

Servo needs no library (driven by HardwareTimer). See
`Documentation/Programming_the_CanSat_in_Arduino_IDE.md` for board settings and
the BOOT0/3V3 upload procedure.

## How it works

The CanSat has three states:
- **Idle** — sends only a heartbeat so the GUI knows it's connected. No logging.
- **Logging** — streams telemetry to the GUI and writes a fresh `logNNN.csv`
  to the SD card. Started/stopped by command from the GUI.
- **Maintenance** — answers on-demand commands (ping, list, download, delete).

The radio link is bidirectional: telemetry goes CanSat→ground, and commands go
ground→CanSat as NRF24 ack payloads (repeated so they aren't lost).

## Using the GUI

Open `GUI/GUI.html` in Chrome or Edge (Web Serial API — desktop only). Close the
Arduino Serial Monitor first so the COM port is free, then click Connect and
pick the ground station's port.

**Logging tab:** Start/Stop Logging, live cards + charts + map, servo slider,
Zero Altitude (rebases barometric altitude to the current position), and a
Download-session-CSV button.

**Setup tab:** Ping Sensors (one fresh reading on demand), and an SD file manager
to list, download, and delete individual log files over the radio.

## Notes

- Telemetry packet: accY, battery ADC, baro altitude, lat, lng, GPS altitude,
  satellites, HDOP (SD-write status is encoded in the sign of the ADC field;
  GPS-alive in the sign of HDOP).
- Barometric altitude is relative to the last Zero (or to standard sea-level
  pressure before zeroing). The raw value on the SD card is what's logged.
- Downloading a big log over the radio is slow (one line per packet); for large
  flight logs it's faster to read the SD card directly on a PC. The download is
  there for convenience and quick checks.
