#include <SPI.h>
#include <nRF24L01.h>
#include <RF24.h>

// ============================================================
//  ARDUINO NANO CANSAT GROUND STATION — command-driven + maintenance
//  NRF24 -> Arduino Nano
//    GND->GND  VCC->3.3V ONLY  CE->D7  CSN->D8
//    SCK->D13  MOSI->D11  MISO->D12
//  Serial / dashboard baud: 115200
//
//  Same command protocol and output as the ESP32 ground station:
//    IN : S:<a> Z LOG:START LOG:STOP PING LIST GET:<n> DEL:<n>
//    OUT: telemetry CSV, #alive, #FILE, #DATA, #END, #DELETED, #PING
//  Plus RPD signal hints (#RSSI / #RX rate).
// ============================================================

#define NRF_CE  7
#define NRF_CSN 8
RF24 radio(NRF_CE, NRF_CSN);
const byte address[6] = "CSAT1";

struct __attribute__((packed)) Telemetry {
  float accY;
  float voltage;
  float baroAlt;
  float lat;
  float lng;
  float gpsAlt;
  float satellites;
  float hdop;
};

struct __attribute__((packed)) TextPacket {
  char tag;
  char text[31];
};

struct __attribute__((packed)) Command {
  uint8_t servoAngle;
  uint8_t zeroAlt;
  uint8_t cmdCode;
  uint8_t arg;
};
Command cmd = { 90, 0, 0, 0 };

// A pending command is re-loaded into the ack payload on every received packet
// until it has been sent several times, because a single ack payload can be
// dropped. This guarantees the CanSat actually receives list/start/etc.
uint8_t pendingCode = 0, pendingArgV = 0;
int pendingRepeat = 0;

unsigned long lastPacket = 0;
unsigned long windowStart = 0;
unsigned long windowPackets = 0;
unsigned long rpdStrongCount = 0;

String pingP = "", pingQ = "", pingR = "";

void armCommand(uint8_t code, uint8_t arg) {
  // Queue the command to be re-sent on the next several packets so it isn't
  // lost if one ack payload is dropped.
  pendingCode = code;
  pendingArgV = arg;
  pendingRepeat = 6;      // re-arm on the next 6 received packets
  cmd.cmdCode = code;
  cmd.arg = arg;
  radio.writeAckPayload(0, &cmd, sizeof(cmd));
}

String inLine = "";
void handleSerialInput() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (inLine.startsWith("S:")) {
        int a = inLine.substring(2).toInt();
        if (a < 0) a = 0; if (a > 180) a = 180;
        cmd.servoAngle = (uint8_t)a;
        radio.writeAckPayload(0, &cmd, sizeof(cmd));
        Serial.print("#servo set to "); Serial.println(a);
      }
      else if (inLine.startsWith("Z")) {
        armCommand(8, 0);   // zero altitude, reliably repeated
        Serial.println("#zero altitude sent");
      }
      else if (inLine.startsWith("LOG:START")) { armCommand(5,0); Serial.println("#logging start sent"); }
      else if (inLine.startsWith("LOG:STOP"))  { armCommand(6,0); Serial.println("#logging stop sent"); }
      else if (inLine.startsWith("PING"))      { armCommand(7,0); Serial.println("#ping sent"); }
      else if (inLine.startsWith("LIST"))      { armCommand(1,0); Serial.println("#list requested"); }
      else if (inLine.startsWith("GET:"))      { armCommand(2,(uint8_t)inLine.substring(4).toInt()); Serial.println("#get requested"); }
      else if (inLine.startsWith("DEL:"))      { armCommand(3,(uint8_t)inLine.substring(4).toInt()); Serial.println("#delete requested"); }
      inLine = "";
    } else {
      inLine += c;
      if (inLine.length() > 24) inLine = "";
    }
  }
}

bool isTextTag(char t) {
  return (t=='H'||t=='L'||t=='D'||t=='d'||t=='N'||t=='E'||t=='X'||t=='P'||t=='Q'||t=='R'||t=='C');
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("#CanSat telemetry CSV: T,accY,adc,sdOK,baroAlt,lat,lng,gpsAlt,sats,hdop,gpsAlive");

  if (radio.begin()) {
    radio.setPALevel(RF24_PA_HIGH);
    radio.setDataRate(RF24_250KBPS);
    radio.setChannel(108);
    radio.enableAckPayload();
    radio.enableDynamicPayloads();
    radio.openReadingPipe(0, address);
    radio.writeAckPayload(0, &cmd, sizeof(cmd));
    radio.startListening();
    Serial.println("#NRF24 OK - waiting for CanSat");
    windowStart = millis();
  } else {
    Serial.println("#NRF24 FAILED - check wiring / 3.3V / decoupling cap");
  }
}

void loop() {
  handleSerialInput();

  if (radio.available()) {
    bool rpd = radio.testRPD();
    uint8_t buf[32];
    radio.read(buf, sizeof(buf));
    lastPacket = millis();
    windowPackets++;
    if (rpd) rpdStrongCount++;

    // Re-arm the pending command (if any) so it survives dropped ack payloads.
    if (pendingRepeat > 0) {
      cmd.cmdCode = pendingCode;
      cmd.arg = pendingArgV;
      pendingRepeat--;
      if (pendingRepeat == 0) { /* stop repeating after this */ }
    } else {
      cmd.cmdCode = 0;
      cmd.arg = 0;
    }
    radio.writeAckPayload(0, &cmd, sizeof(cmd));

    char tag = (char)buf[0];
    if (isTextTag(tag)) {
      TextPacket* tp = (TextPacket*)buf;
      char t = tp->tag;
      char text[31]; memcpy(text, tp->text, 30); text[30] = 0;

      if (t == 'H')      Serial.println("#alive");
      else if (t == 'L'){ Serial.print("#FILE "); Serial.println(text); }
      else if (t == 'N'){ Serial.print("#FNAME "); Serial.println(text); }
      else if (t == 'D'){ Serial.print("#DCONT "); Serial.println(text); }
      else if (t == 'd'){ Serial.print("#DATA "); Serial.println(text); }
      else if (t == 'X'){ Serial.print("#DELETED "); Serial.println(text); }
      else if (t == 'E') Serial.println("#END");
      else if (t == 'P') pingP = text;
      else if (t == 'Q') pingQ = text;
      else if (t == 'R') {
        pingR = text;
        Serial.print("#PING ");
        Serial.print(pingP); Serial.print(',');
        Serial.print(pingQ); Serial.print(',');
        Serial.println(pingR);
        pingP = pingQ = pingR = "";
      }
    } else {
      Telemetry* tlm = (Telemetry*)buf;
      bool sdOK = (tlm->voltage >= 0);
      long adc = (long)fabs(tlm->voltage);
      bool gpsAlive = (tlm->hdop < 0);
      float hdopAbs = fabs(tlm->hdop);

      Serial.print(millis());      Serial.print(',');
      Serial.print(tlm->accY, 3);  Serial.print(',');
      Serial.print(adc);           Serial.print(',');
      Serial.print(sdOK ? 1 : 0);  Serial.print(',');
      Serial.print(tlm->baroAlt,2);Serial.print(',');
      Serial.print(tlm->lat, 6);   Serial.print(',');
      Serial.print(tlm->lng, 6);   Serial.print(',');
      Serial.print(tlm->gpsAlt,2); Serial.print(',');
      Serial.print((int)tlm->satellites); Serial.print(',');
      Serial.print(hdopAbs,2);     Serial.print(',');
      Serial.println(gpsAlive ? 1 : 0);
    }
  }

  // RPD summary every 5 s
  if (millis() - windowStart >= 5000) {
    if (windowPackets > 0) {
      float strong = ((float)rpdStrongCount / (float)windowPackets) * 100.0;
      Serial.print("#RPD strong: "); Serial.print(strong, 0); Serial.println("%");
    }
    windowPackets = 0; rpdStrongCount = 0; windowStart = millis();
  }

  if (millis() - lastPacket > 4000 && lastPacket != 0) {
    Serial.println("#link lost");
    lastPacket = millis();
  }
}
